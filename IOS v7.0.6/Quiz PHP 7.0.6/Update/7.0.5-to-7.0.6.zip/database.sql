UPDATE `settings` SET `message` = '7.0.6' WHERE `settings`.`type` = 'quiz_version';
