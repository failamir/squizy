<?php
return array(
    'current_version'=>'7.0.1',
    'update_version'=>'7.0.4'
);
