
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">

        <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
        <meta http-equiv="Pragma" content="no-cache">
        <meta http-equiv="Expires" content="0"> 

        <meta name="author" content="Kukode">
        <meta name="copyright" content="Kukode.in">
        <meta name="keywords" content="Quiz online, Web Quiz">
        <meta name="description" content="Make the perfect online quiz for any subject! Get the flexibility you need to get the answers you want. The Quiz Online power by Kukode.in Maker makes it easy for you to see what people know.">

        <link href="assets/images/icon.png" rel="shortcut icon"/>
        <link href="assets/css/bootstrap.css" rel="stylesheet" type="text/css"/> 
        <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Baloo&display=swap" />
        <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Lobster" />
        <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />
        <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css"/>
        <!-- DataTables -->
        <link href="//cdn.datatables.net/1.10.21/css/jquery.dataTables.min.css" rel="stylesheet">
        <link href="assets/css/animate.min.css" rel="stylesheet" type="text/css"/>
        <link href="assets/css/intlTelInput.css" rel="stylesheet" type="text/css">
        <link href="assets/css/style.css" rel="stylesheet" type="text/css"/>
        <link href="assets/css/login.css" rel="stylesheet" type="text/css"/>
        
        <script src="assets/js/jquery.min.js"></script> 
        <script src="assets/js/bootstrap.js"></script>      
        <script src="assets/js/sweetalert.min.js" ></script>
        <script src="assets/js/jquery.redirect.js"></script> 
        <script src="assets/js/jquery.blockUI.min.js" ></script>
        <script src="assets/js/wow.min.js"></script>
        <script src="assets/js/smooth-scroll.min.js"></script>
        <script src="assets/js/progressbar.js"></script>  
        <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js" integrity="sha512-bPs7Ae6pVvhOSiIcyUClR7/q2OAsRiovw4vAkX+zJbw3ShAeeqezq50RIIcIURq7Oa20rW2n2q+fyXBNcU9lrw==" crossorigin="anonymous"></script>

        <!-- DataTables -->
        <script src="//cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>

        <script src="https://www.gstatic.com/firebasejs/5.7.2/firebase.js"></script>

        <script src="assets/js/constant.js"></script> 
        <script src="assets/js/webquiz.js"></script>
        <script src="assets/js/config.js"></script>         
        <script src="assets/js/signup.js"></script> 
        <script src="assets/js/intlTelInput.js"></script>