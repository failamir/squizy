<?php
return array(
    'current_version'=>'7.0.2',
    'update_version'=>'7.0.3'
);
