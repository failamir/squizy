<?php
return array(
    'current_version'=>'7.0.3',
    'update_version'=>'7.0.4'
);
